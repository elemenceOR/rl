import numpy as np
import gymnasium as gym
from gymnasium import Env, spaces
import pygame as py

class OverheadCrane(Env):
    
    '''
    States :
            {
            x : distance
            (ẋ) x_dot : velocity
            theta : sway angle
            (θ̇ ) theta_dot : angular velocity
            x_target : target positon
            }
    
    actions : 
            {
            continuous force :f
            }

    constants :
            {
            gravity : g
            cart mass : m_C
            load mass : m_l
            load cable length : l
            }

    Non-Liner equations :
            {
            ẍ = [F + m_L Lθ̇² sinθ + m_L g sinθ cosθ] / (M + m_L sin²θ)

            θ̈ = [-F cosθ - m_L Lθ̇² sinθ cosθ - (M + m_L)g sinθ] / [L(M + m_L sin²θ)]
            }
    '''

    metadata = {"render_modes": ["human", "rgb_array"], "render_fps": 50}

    def __init__(self, render_mode=None, options=None, w_dist=20.0, w_angle=15.0, w_vel=12.0, w_ang_vel=2.0):
        super().__init__()

        self.w_dist = w_dist
        self.w_angle = w_angle
        self.w_vel = w_vel
        self.w_ang_vel = w_ang_vel

        self.g = 9.81
        self.m_c = 10.0 #kg
        self.m_l = 2.0 #kg
        self.l = 1.5 #m

        #movement constrains
        self.max_cart_pos = 10.0 #m
        self.max_cart_vel = 10.0 #m
        self.max_sway_angle = 0.5 #rad
        self.max_sway_vel = 1.0 #ras/s

        self.time_step = 0.02 #20ms (50Hz)

        self.max_force = 100.0 #N


        #(new)success_criteria - tolenrces to messuer how succesfull the step was
        self.position_tol = 0.05
        self.angle_tol = 0.05
        self.velocity_tol = 0.05
        self.angular_vel_tol = 0.05
        self.hold_steps_req = 100 #hold the position for 1 seocnd


        #single action space (box)
        self.action_space = spaces.Box(
            low=-self.max_force,
            high=self.max_force,
            shape=(1,),
            dtype=np.float32
        )

        low_bounds = np.array([
            -self.max_cart_pos, -self.max_cart_vel, 
            -self.max_sway_angle, -self.max_sway_vel, 
            -self.max_cart_pos
        ], dtype=np.float32)
        
        high_bounds = np.array([
            self.max_cart_pos, self.max_cart_vel, 
            self.max_sway_angle, self.max_sway_vel, 
            self.max_cart_pos
        ], dtype=np.float32)

        self.observation_space = spaces.Box(
            low=low_bounds,
            high=high_bounds,
            dtype=np.float32
        )

        #states for reset
        self.state = None
        self.target_position = 0.0
        self.steps_taken = 0
        self.max_steps_episode = 3000

        self.render_mode = render_mode
        self.screen_width = 800
        self.screen_height = 400
        self.screen = None
        self.clock = None
        self.isopen = True

        self.reward_distribution_norm = 2.0 #maxumum tollarance error distance from target

        self.world_scale = self.screen_width / (self.max_cart_pos*2)

        self.target_range = 5.0 #m 
        self.target_position = 0.0
        

        print("Crane Initialized")
    
    def set_cl_paramenters(self, max_force, traget_range, max_angle_rad=None):
        '''function to setup curriculum learning'''
        self.max_force = max_force

        self.action_space = spaces.Box(
            low=-self.max_force,
            high=self.max_force,
            shape=(1,),
            dtype=np.float32
        )

        if max_angle_rad is not None:
            self.max_sway_angle = max_angle_rad
        
        self.target_range = traget_range
        print(f"\n--- ENV UPDATED --- MaxForce: {max_force:.1f}N | TargetRange: {traget_range:.1f}m ---")


    def reset(self, seed=None, options=None):
        super().reset(seed=seed)

        #small random noise
        self.state = self.np_random.uniform(low=-0.05, high=0.05, size=4) #size = 4; 4 obserbable variables

        #self.target_position = self.np_random.uniform( low=-self.target_range, high=self.target_range)

        self.target_position = self.target_range

        self.steps_taken = 0
        self.hold_steps = 0

        observation = self._get_observation()

        info = self._get_info()

        if self.render_mode == "human":
            self._render_frame()

        return observation, info


    def step(self, action):
        
        f = action[0] #single force , 1-element array.

        x, x_dot, theta, theta_dot = self.state

        ct = np.cos(theta)
        st = np.sin(theta)

        x_ddot = (f + self.m_l * self.l * theta_dot * theta_dot * st + self.m_l * self.g * st * ct) / (self.m_c + self.m_l * st * st)

        theta_ddot = (-f * ct - self.m_l * self.l * theta_dot * theta_dot * st * ct - (self.m_c + self.m_l) * self.g * st) / (self.l * (self.m_c + self.m_l * st * st))

        #state update - Euler integration
        x_dot = x_dot + (x_ddot * self.time_step)
        x = x + (x_dot * self.time_step)
        
        theta_dot = theta_dot + (theta_ddot * self.time_step)
        theta = theta + (theta_dot * self.time_step)

        self.state = np.array([x, x_dot, theta, theta_dot], dtype=np.float32)
        self.steps_taken += 1

        #terminating codiotns
        '''
        1. cart go off boundry from left
        2. cart go off boundrt from right
        3. swing over the minimun angle
        4. " " " " " " " " " " " " " "
        '''

        terminated = bool(
            x < -self.max_cart_pos or x > self.max_cart_pos or theta < -self.max_sway_angle or theta > self.max_sway_angle
        )

        #shaped reward system 

        '''
        1. getting to the target posiotn
        2. minimizeing the sway angle (theta)
        3. minimizing sway velocity
        4. weighted reward
        5. panelty for failed attempets (terminating conditions)
        '''

        reward = 0

        #if not terminated:
        #    dist_to_tgt = np.abs(x - self.target_position)
        #    reward_dist = 1.0 - (dist_to_tgt/self.max_cart_pos)

        #    reward_sway = 1.0 - (np.abs(theta)/self.max_sway_angle)

        #    reward_damp = 1.0 - (np.abs(theta_dot)/self.max_sway_vel)

        #    reward = (5.0*reward_dist) + reward_sway + (0.5*reward_damp)  #weigh each reward depending on the importance
        #else:
        #    reward = -100.0

        dist_to_tgt = np.abs(x - self.target_position)

        at_target = (
            dist_to_tgt < self.position_tol and
            np.abs(theta) < self.angle_tol and
            np.abs(x_dot) < self.velocity_tol and
            np.abs(theta_dot) < self.angular_vel_tol
        )

        if at_target:
            self.hold_steps +=1
        else:
            self.hold_steps = 0

        suceess = self.hold_steps > self.hold_steps_req

        dist_reward = 1.0 - (dist_to_tgt / self.reward_distribution_norm)
        dist_reward = np.clip(dist_reward, 0.0, 1.0)

        angle_reward = 1.0 - (np.abs(theta) / self.max_sway_angle)
        velocity_reward = 1.0 - (np.abs(x_dot) / self.max_cart_vel)
        angle_vel_reward = 1.0 - (np.abs(theta_dot) / self.max_sway_vel)

        step_reward = (
            (self.w_dist * dist_reward) + 
            (self.w_angle * angle_reward) + 
            (self.w_vel * velocity_reward) + 
            (self.w_ang_vel * angle_vel_reward)
        )

        #panelty for using force aggresive to achive target
        normalize_force = f / self.max_force
        effort_panelty = -0.05 * (normalize_force**2)

        reward = step_reward + effort_panelty

        if terminated:
            if suceess:
                reward = step_reward + 100.0 
            else:
                reward = -10.0 
        else:
            reward = step_reward

        truncated = bool(self.steps_taken >= self.max_steps_episode)

        if suceess:
            terminated = True

        observation = self._get_observation()
        info = self._get_info()

        if self.render_mode == "human":
            self._render_frame()

        return observation, reward, terminated, truncated, info
    
    def render(self):
        return self._render_frame()
    
    def close(self):
        if self.screen is not None:
            py.display.quit()
            py.quit()
            self.isopen = False
            self.screen = False
            self.clock = False
    
    def _get_observation(self):
        '''Helper function for observation vector'''
        x, x_dot, theta, theta_dot = self.state
        
        return np.array([x, x_dot, theta, theta_dot, self.target_position], dtype=np.float32)
    
    def _get_info(self):
        '''Helper to return internal info'''

        return {
            "target pos" : self.target_position,
            "distance to tgt" : np.abs(self.state[0]-self.target_position),
            "sway agl" : self.state[2]
        }

    def _render_frame(self):
        if self.screen is None:
            py.init()
            if self.render_mode == "human":
                py.display.set_caption("Overhead Crane Simulation")
                self.screen = py.display.set_mode(
                    (self.screen_width, self.screen_height)
                )
            else:
                self.screen = py.display.set_mode((self.screen_width, self.screen_height))
        
        if self.clock is None:
            self.clock = py.time.Clock()

        #Converts from world coordinates (meters) to screen (pixels)
        def to_pixels(world_x):
            # Center of screen is x=0
            return int(self.screen_width / 2 + world_x * self.world_scale)

        x, _, theta, _ = self.state
        
        #Background
        self.screen.fill((255, 255, 255))
        
        #Track
        track_y = 100 
        py.draw.line(
            self.screen, 
            (0, 0, 0), 
            (0, track_y), 
            (self.screen_width, track_y), 
            width=2
        )
        
        #Draw Target 
        target_x_pixels = to_pixels(self.target_position)
        py.draw.line(
            self.screen,
            (0, 200, 0),
            (target_x_pixels, 0),
            (target_x_pixels, self.screen_height),
            width=1,
        )

        #Draw Start
        start_x_pixels = to_pixels(0)
        py.draw.line(
            self.screen,
            (150, 150, 150),
            (start_x_pixels, 50),
            (start_x_pixels, self.screen_height),
            width=1
        )

        #Cart and Load Positions
        cart_x_pixels = to_pixels(x)
        cart_y_pixels = track_y
        
        # Cable length
        cable_len_pixels = self.l * self.world_scale
        
        # Load position
        load_x_pixels = cart_x_pixels + cable_len_pixels * np.sin(theta)
        load_y_pixels = cart_y_pixels + cable_len_pixels * np.cos(theta)
        
        #Cable
        py.draw.line(
            self.screen,
            (50, 50, 50),
            (int(cart_x_pixels), int(cart_y_pixels)),
            (int(load_x_pixels), int(load_y_pixels)),
            width=2
        )
        
        #Cart
        cart_width = 50
        cart_height = 30
        py.draw.rect(
            self.screen,
            (200, 0, 0),
            py.Rect(
                cart_x_pixels - cart_width / 2,
                cart_y_pixels - cart_height / 2,
                cart_width,
                cart_height
            )
        )
        
        #Load 
        load_radius = 10
        py.draw.circle(
            self.screen,
            (0, 0, 200),
            (int(load_x_pixels), int(load_y_pixels)),
            load_radius
        )

        #state info
        if self.clock:
            font = py.font.Font(None, 24)
            dist = np.abs(x - self.target_position)
            info_text = f"Distance: {dist:.2f}m  Angle: {theta:.3f}rad  Steps: {self.steps_taken}"
            text_surface = font.render(info_text, True, (0, 0, 0))
            self.screen.blit(text_surface, (10, 10))
        
        # Update the display
        if self.render_mode == "human":
            py.event.pump()
            py.display.flip()
            self.clock.tick(self.metadata["render_fps"])
        elif self.render_mode == "rgb_array":
            return np.transpose(np.array(py.surfarray.pixels3d(self.screen)), axes=(1,0,2))