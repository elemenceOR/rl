import gymnasium as gym
from stable_baselines3 import PPO
import matplotlib.pyplot as plt
#from gymnasium.wrappers import RecordVideo
import imageio
import numpy as np
from gymnasium.envs.registration import register

from crane import OverheadCrane

register(
    id='OverheadCrane-v0',
    entry_point='crane:OverheadCrane',
    max_episode_steps=3000
)

def step_responce(model_path, target_pos = 5.0, video_folder="video_output", filename='crane.gif'):
    env = gym.make("OverheadCrane-v0", render_mode="rgb_array")

    #env = RecordVideo(env, video_folder=video_folder, episode_trigger=lambda episode_id:True, name_prefix='crane_agent')

    model = PPO.load(model_path)

    obs, info = env.reset()

    env_unwrapped = env.unwrapped
    env_unwrapped.state = np.array([0.0, 0.0, 0.0, 0.0])
    env.unwrapped.target_position = target_pos

    obs = env_unwrapped._get_observation()

    time_data = []
    x_data = []
    x_dot_data = []
    theta_data = []
    theta_dot_data = []
    force_data = []

    print(f"targer: {target_pos}")

    done = False
    truncated = False
    steps = 0

    frames=[]

    while not truncated:
        action, _ = model.predict(obs, deterministic=True)
        
        obs, reward, done, truncated, info = env.step(action)
        
        state = env_unwrapped.state
        time_data.append(steps * env_unwrapped.time_step)
        x_data.append(state[0])
        x_dot_data.append(state[1])
        theta_data.append(state[2])
        theta_dot_data.append(state[3])
        force_data.append(action[0])
        
        steps += 1

        frame = env.render()
        frames.append(frame)

    env.close()

    print("saving gif")
    imageio.mimsave(filename, frames, fps=30)
    print("gif saved")
    
    fig, axs = plt.subplots(3, 2, figsize=(12, 10))
    fig.suptitle(f'Step Response Analysis (Target = {target_pos}m)', fontsize=16)

    # 1. Position (x)
    axs[0, 0].plot(time_data, x_data, label='Cart Position', color='blue')
    axs[0, 0].axhline(y=target_pos, color='green', linestyle='--', label='Target')
    axs[0, 0].set_title('Cart Position (x)')
    axs[0, 0].set_ylabel('Meters')
    axs[0, 0].legend()
    axs[0, 0].grid(True)

    # 2. Velocity (x_dot)
    axs[1, 0].plot(time_data, x_dot_data, color='orange')
    axs[1, 0].set_title('Cart Velocity (x_dot)')
    axs[1, 0].set_ylabel('m/s')
    axs[1, 0].grid(True)

    # 3. Sway Angle (theta)
    axs[0, 1].plot(time_data, np.degrees(theta_data), color='red') # Convert to degrees for readability
    axs[0, 1].set_title('Sway Angle (theta)')
    axs[0, 1].set_ylabel('Degrees')
    axs[0, 1].grid(True)

    # 4. Angular Velocity (theta_dot)
    axs[1, 1].plot(time_data, theta_dot_data, color='purple')
    axs[1, 1].set_title('Sway Velocity (theta_dot)')
    axs[1, 1].set_ylabel('rad/s')
    axs[1, 1].grid(True)
    
    # 5. Action (Force)
    axs[2, 0].plot(time_data, force_data, color='black')
    axs[2, 0].set_title('Control Action (Force)')
    axs[2, 0].set_ylabel('Newtons')
    axs[2, 0].set_xlabel('Time (seconds)')
    axs[2, 0].grid(True)

    axs[2, 1].axis('off')

    plt.tight_layout()
    plt.show()

if __name__ == "__main__":
    step_responce("ppo_crane_curriculum_final9")