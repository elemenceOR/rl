from gymnasium.utils.env_checker import check_env
from crane import OverheadCrane


env = OverheadCrane()

try:
    check_env(env)
    print("good")
except Exception as e:
    print("error", e)

