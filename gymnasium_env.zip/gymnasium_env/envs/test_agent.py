import gymnasium as gym
from stable_baselines3 import PPO
import time

from crane import OverheadCrane

from gymnasium.envs.registration import register
register(
    id='OverheadCrane-v0',
    entry_point='crane:OverheadCrane',
    max_episode_steps=3000
)

env = gym.make("OverheadCrane-v0", render_mode="human")

model = PPO.load("crane_model_ppo6")
print("Model loaded. Starting test...")

obs, info = env.reset()
done = False
truncated = False

while not done and not truncated:
    action, _states = model.predict(obs, deterministic=True)
    
    obs, reward, done, truncated, info = env.step(action)
    env.render() 
    time.sleep(0.02) 

print("Test complete.")
env.close()