import gymnasium as gym
from stable_baselines3 import PPO
import os
from gymnasium.envs.registration import register
from crane import OverheadCrane
from stable_baselines3.common.monitor import Monitor

register(
    id='OverheadCrane-v0',
    entry_point='crane:OverheadCrane', 
    max_episode_steps=3000
)

CURRICULUM = [
    {
        "name": "Phase 1: Stabilization",
        "timesteps": 1_000_000,
        "max_force": 25.0,       # Start with low power
        "target_range": 0.0,     # Target is always 0.0m (Balancing task)
        "log_folder": "P1_Stabilization"
    },
    {
        "name": "Phase 2: Local Transit",
        "timesteps": 2_500_000,  # Longer time to learn movement
        "max_force": 50.0,       # Increase power
        "target_range": 2.0,     
        "log_folder": "P2_Local_Transit"
    },
    {
        "name": "Phase 3: Full-Span Transit",
        "timesteps": 3_000_000,  # Longest time for complex generalization
        "max_force": 100.0,      # Full power
        "target_range": 5.0,     
        "log_folder": "P3_Full_Span"
    }
]

env = gym.make("OverheadCrane-v0")
env_unwrapped = env.unwrapped

log_dir = "./ppo_cl9/"
os.makedirs(log_dir, exist_ok=True)
env = Monitor(env, log_dir)

print("environment created")

model = PPO("MlpPolicy", 
            env, 
            verbose=1,
            learning_rate=3e-04,
            n_steps=2048,
            batch_size=64,
            n_epochs=10,
            gamma=0.99,
            gae_lambda=0.987531620135791,
            clip_range=0.2,
            tensorboard_log=log_dir)

print("model created")

print("==============================")

for phase in CURRICULUM:
    print(f"\n################ STARTING {phase['name']} ################")
    
    env_unwrapped.set_cl_paramenters(
        phase["max_force"], 
        phase["target_range"]
    )
    
    model.learn(
        total_timesteps=phase["timesteps"],
        reset_num_timesteps=False, 
        tb_log_name=phase["log_folder"] 
    )
    
phase_f_model = "ppo_crane_curriculum_final9"
model.save(phase_f_model)

print("\n--- CURRICULUM TRAINING COMPLETE ---")
print(f"Final model saved as: {phase_f_model}.zip")
env.close()