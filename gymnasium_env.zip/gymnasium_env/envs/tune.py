import optuna
from optuna.visualization import plot_optimization_history, plot_param_importances
from stable_baselines3 import PPO
from stable_baselines3.common.evaluation import evaluate_policy
from stable_baselines3.common.callbacks import EvalCallback
import gymnasium as gym
import logging
import sys
from datetime import datetime
import os
from stable_baselines3.common.monitor import Monitor

from gymnasium.envs.registration import register
from crane import OverheadCrane

register(
    id='OverheadCrane-v0',
    entry_point='crane:OverheadCrane', 
    max_episode_steps=3000
)

log_dir = f"logs/optuna_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
os.makedirs(log_dir, exist_ok=True)

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    handlers=[
        logging.FileHandler(f"{log_dir}/optimization.log"),
        logging.StreamHandler(sys.stdout),
    ],
)
logger = logging.getLogger(__name__)


def objective(trial):
    logger.info(f"Starting trial {trial.number}")

    # Sample hyperparameters
    learning_rate = trial.suggest_float("learning_rate", 1e-5, 5e-3, log=True)
    gamma = trial.suggest_float("gamma", 0.9, 0.9999)
    n_steps = trial.suggest_categorical("n_steps", [1024, 2048, 4096])
    batch_size = trial.suggest_categorical("batch_size", [32, 64, 128])
    gae_lambda = trial.suggest_float("gae_lambda", 0.9, 0.99)
    ent_coef = trial.suggest_float("ent_coef", 0.0, 0.01)
    clip_range = trial.suggest_float("clip_range", 0.1, 0.3)

    # Sample reward weights
    w_dist = trial.suggest_float("w_dist", 5.0, 30.0)
    w_angle = trial.suggest_float("w_angle", 10.0, 50.0)
    w_vel = trial.suggest_float("w_vel", 1.0, 15.0)

    logger.info(f"Trial {trial.number} params: lr={learning_rate:.6f}, gamma={gamma:.4f}, "
                f"n_steps={n_steps}, batch={batch_size}, gae={gae_lambda:.3f}, "
                f"ent={ent_coef:.4f}, clip={clip_range:.3f}")
    logger.info(f"Trial {trial.number} reward weights: w_dist={w_dist:.2f}, "
                f"w_angle={w_angle:.2f}, w_vel={w_vel:.2f}")

    try:
        env = Monitor(gym.make(
            "OverheadCrane-v0",
            w_dist=w_dist,
            w_angle=w_angle,
            w_vel=w_vel,)
        )

        eval_env = Monitor(gym.make(
            "OverheadCrane-v0",
            w_dist=w_dist,
            w_angle=w_angle,
            w_vel=w_vel,)
        )

        # Create trial-specific log directory for tensorboard
        trial_log_dir = f"{log_dir}/trial_{trial.number}"
        os.makedirs(trial_log_dir, exist_ok=True)

        model = PPO(
            "MlpPolicy",
            env,
            learning_rate=learning_rate,
            gamma=gamma,
            n_steps=n_steps,
            batch_size=batch_size,
            gae_lambda=gae_lambda,
            ent_coef=ent_coef,
            clip_range=clip_range,
            n_epochs=10,
            verbose=0,
            tensorboard_log=trial_log_dir,
        )

        # Eval callback for pruning
        eval_callback = EvalCallback(
            eval_env,
            n_eval_episodes=5,
            eval_freq=50_000,
            verbose=0,
        )

        model.learn(total_timesteps=500_000, callback=eval_callback)

        mean_reward, std_reward = evaluate_policy(model, eval_env, n_eval_episodes=10)

        logger.info(f"Trial {trial.number} finished: mean_reward={mean_reward:.2f} +/- {std_reward:.2f}")

        env.close()
        eval_env.close()

        return mean_reward

    except Exception as e:
        logger.error(f"Trial {trial.number} failed: {e}")
        raise optuna.TrialPruned()


def logging_callback(study, trial):
    logger.info(f"Trial {trial.number} completed with value: {trial.value}")
    logger.info(f"Best trial so far: {study.best_trial.number} with value: {study.best_value:.2f}")


if __name__ == "__main__":
    logger.info("Starting optimization")

    study = optuna.create_study(
        direction="maximize",
        study_name="crane_reward_opt",
        storage="sqlite:///optuna_crane.db",
        load_if_exists=True,
        pruner=optuna.pruners.MedianPruner(n_startup_trials=5, n_warmup_steps=3),
    )

    study.optimize(
        objective,
        n_trials=100,
        n_jobs=1,
        callbacks=[logging_callback],
        show_progress_bar=True,
    )

    # Log final results
    logger.info("=" * 50)
    logger.info("Optimization finished!")
    logger.info(f"Best trial: {study.best_trial.number}")
    logger.info(f"Best value: {study.best_trial.value:.2f}")
    logger.info("Best params:")
    for k, v in study.best_trial.params.items():
        logger.info(f"  {k}: {v}")

    # Save visualization plots
    try:
        fig = plot_optimization_history(study)
        fig.write_html(f"{log_dir}/optimization_history.html")

        fig = plot_param_importances(study)
        fig.write_html(f"{log_dir}/param_importances.html")

        logger.info(f"Plots saved to {log_dir}/")
    except Exception as e:
        logger.warning(f"Could not generate plots: {e}")